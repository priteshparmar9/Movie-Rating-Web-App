import React, { useState } from "react";
import axios from "axios";
import swal from "sweetalert";
import "../css/signup.css";

function Signup() {

    const [user, setUser] = useState({
        username: "",
        email: "",
        password: "",
        re_password: "",
    })
    const [ResponseStatus, setResponseStatus] = useState();

    const handler = e => {
        const { name, value } = e.target;
        setUser({
            ...user,
            [name]: value
        })
        console.log(user);
    }
    const try_login = async () => {
        if (user.username && user.password === user.re_password && user.password && user.email) {


            const url = 'http://localhost:9000/user/signup';
            const { username, email, password } = user
            await axios.post(url, user).then(res => setResponseStatus(res.data));
            swal('Great!', 'Signup successful!', 'success');
        }
        else if (user.re_password != user.password) {
            swal('Opps!', 'Both passwords are not matching!', 'warning');
        }
        else {
            swal('Opps!', 'Please enter all data!', 'warning');
        }
    }

    return (
        <>
            <div className="card-body">
            <h3 className="signup">Create Account</h3>
            <label for="username">Your Username</label><br/>
            <input type="text" name="username" value={user.username}  placeholder="Username" onChange={handler}/><br/>
            <label for="email">Email</label><br/>
            <input type="text" name="email" value={user.email} onChange={handler}  placeholder="Your Email"/>
            <label for="pwd">Password</label><br/>
            <input type="password" name="password" value={user.password} onChange={handler}  placeholder="Your Password"/><br/>
            <label for="rpwd">Re-Enter Password</label><br/>
            <input type="password" id="rpwd" name="re_password" value={user.re_password} onChange={handler} placeholder="Re-enter Your Password"/><br/>
            <br />
            <button className="button" value={"Create Your Account"}  onClick={try_login}>Create Your Account</button>
            <br/><br/>
            <p>Already have account?<a href="/login"> Sign in</a></p>
            </div>
        </>
    );
}
export default Signup;