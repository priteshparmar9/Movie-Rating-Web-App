import React, { useEffect, useState } from "react";
import axios from "axios";
import SmallCard from "./SmallCard";
import Slider from "./Slider";
import './css/Content.css';
import { Navigate } from "react-router-dom";
import Cards from "./Card";

function Content() {
  const [movie, setMovie] = useState([]);

  let url = 'http://localhost:9000/movie/';
  useEffect(
    () => {
      function fetchData() {
        axios.get(url).then(
          (response) => {
            setMovie(response.data);
            console.log(movie);
          }
        ).catch(
          console.log('Error')
        )
      }
      fetchData();
    }, []
  )
  let DisplayMovies = () => {
    return (
      <>
        {
          movie.map(
            (mov1, index) => {
              let movUrl = '../movie/' + mov1._id;
              // <li>{mov1.title}</li>
              return (
                <>
                  <Cards movie={mov1}/>
                </>
    )
  }
          )

}
      </>
    )
  }

return (
  <>
    <h1>
      <Slider />
      {DisplayMovies()}
    </h1>
  </>
)
}

export default Content;