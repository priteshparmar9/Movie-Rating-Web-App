import React from "react";

function MovieCard_Proper(props){
    
}

export default MovieCard_Proper;