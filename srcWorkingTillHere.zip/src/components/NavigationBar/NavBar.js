import { Navbar, Container, Nav, NavDropdown } from 'react-bootstrap';
import { useState } from "react";
import { Navigate, redirect, useLinkClickHandler } from "react-router-dom"
import Select from 'react-select';
import '../../css/NavBar.css';

function NavBar() {

    const [searchItem, setSearchItem] = useState();

    function Search(event) {
        event.preventDefault();
    }

    const searchOptions = [
        {
            value: 'Movie', label: 'Movies'
        },
        {
            value: 'Actor', label: 'Actors'
        },
    ]

    function handler(event) {
        setSearchItem(event.target.value);
        console.log(searchItem);
    }

    function ShowLogout() {
        function logout() {
            window.localStorage.removeItem('isLoggedIn')
            window.localStorage.removeItem('username')
            window.location.reload();
        }

        return (
            <button type="button" className="btn btn-primary ml-2" onClick={logout}>Logout</button>
        )
    }

    return (
        <>

            <Navbar fixed='top' expand="lg" style={{ backgroundColor: 'black' }}>
                <Container>
                    <Navbar.Brand href="../"
                        style={
                            {
                                font: '2em Impact, HelveticaNeue-CondensedBold, sans-serif',
                                color: '#000',
                                textShadow: '0 0 0.15em #fff',
                                textDecoration: 'none',
                                display: 'inline-block',
                                verticalAlign: 'bottom',
                                padding: '0.10em 0.25em',
                                borderRadius: '0.15em',
                                background: 'radial-gradient(#ffffb8, #ce981d)',
                            }
                        }
                    >MovieDB</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            {
                                window.localStorage.getItem('isLoggedIn') ?
                                    <>
                                        {
                                            ShowLogout()
                                        }
                                        {
                                            (window.localStorage.getItem('username') == 'admin') ?
                                                <>
                                                    <Nav.Link href="./addmovie" placement="bottom" className='linkText'>Add Movie</Nav.Link>
                                                    <Nav.Link href="./addcast" placement="bottom" className='linkText'>Add Cast</Nav.Link>
                                                </>
                                                :
                                                <>
                                                </>
                                        }
                                    </>
                                    :
                                    <>
                                        <Nav.Link href="./login" className='linkText'
                                            style={
                                                {
                                                    font: '2em Impact, sans-serif',
                                                    color: '#fff',
                                                    textDecoration: 'none',
                                                    display: 'inline-block',
                                                    verticalAlign: 'bottom',
                                                    padding: '0.10em 0.25em',
                                                    borderRadius: '0.15em',
                                                }
                                            }

                                        >Login</Nav.Link>
                                        <Nav.Link href="./signup" className='linkText'
                                            style={
                                                {
                                                    font: '2em Impact, sans-serif',
                                                    color: '#fff',
                                                    textDecoration: 'none',
                                                    display: 'inline-block',
                                                    verticalAlign: 'bottom',
                                                    padding: '0.10em 0.25em',
                                                    borderRadius: '0.15em',
                                                }
                                            }
                                        >Signup</Nav.Link>
                                    </>
                            }
                            {/* <NavDropdown title="Dropdown" id="basic-nav-dropdown">
                                <NavDropdown.Item href="#action/3.1">Item 1</NavDropdown.Item>
                                <NavDropdown.Item href="#action/3.2">Item 2</NavDropdown.Item>
                                <NavDropdown.Item href="#action/3.3">Item 3</NavDropdown.Item>
                                <NavDropdown.Divider />
                                <NavDropdown.Item href="#action/3.4">Separated Item</NavDropdown.Item>
                            </NavDropdown> */}
                            <form className="d-flex" action="/query" method="get">
                                <div className="col-md-2 col-lg-5 col-xl-5">
                                    <Select
                                        options={searchOptions}
                                    />
                                </div>
                                <input id="search" className="form-control mr-2 col-md-6 col-lg-9 col-xl-12" value={searchItem} onChange={handler} type="search" placeholder="Search" aria-label="Search" />
                                <button className="btn btn-outline-success" onClick={Search}>Search</button>
                            </form>

                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
        </>
    );
}
export default NavBar;  