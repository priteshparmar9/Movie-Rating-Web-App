import React from 'react';
import { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation, Pagination } from 'swiper';
import axios from 'axios';
import SwiperCore from 'swiper';
import 'swiper/swiper-bundle.css';
import { useRef } from 'react';
import 'swiper/css';
import './css/Slider.css';
import SmallCard from './SmallCard';


function Slider() {

  const [movie, setMovie] = useState([]);

  let url = 'http://localhost:9000/movie/';
  useEffect(
    () => {
      function fetchData() {
        axios.get(url).then(
          (response) => {
            setMovie(response.data);
          }
        ).catch(
          console.log('Error')
        )
      }
      fetchData();
    }, []
  )

  return (
    <>
      <div style={{ width: '100%', height: '100vh', overflow: 'hidden', margin: '10px' }}>
        <Swiper
          centeredSlides={true}
          autoplay={{
            Delay: 1500,
            DisableOnInteraction: false
          }}
          speed={2000}
          modules={[Autoplay, Navigation, Pagination]}
        >
          {
            movie.map(
              (mov1) => {
                return (
                  <SwiperSlide>
                    {/* <a href={'../movie/'+mov1._id}>
                      <div>
                        <img className='swipeImage' src={mov1.poster} />
                        {mov1.title}
                      </div>
                    </a> */}
                    <SmallCard movie={mov1}/>
                  </SwiperSlide>
                )
              }
            )
          }
        </Swiper>
      </div>
    </>
  );
}

export default Slider;